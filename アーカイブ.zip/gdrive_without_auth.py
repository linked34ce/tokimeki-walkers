from pydrive.drive import GoogleDrive
from pydrive.auth import GoogleAuth

import os

gauth = GoogleAuth()

gauth.LoadCredentialsFile("credentials.txt")

if gauth.credentials is None:
    gauth.LocalWebserverAuth()   
elif gauth.access_token_expired:
    gauth.Refresh() 
else:
    gauth.Authorize() 
gauth.SaveCredentialsFile("credentials.txt") 
       
drive = GoogleDrive(gauth)

folder_id = drive.ListFile({"q": "title = 'graduation_research_tmp'"}).GetList()[0]["id"]

path = "/Users/oki_kurihara/graduation_research/static/tmp"

for x in os.listdir(path):
    f = drive.CreateFile({"parents": [{"id": folder_id}], "title" : x})
    f.SetContentFile(os.path.join(path, x))
    f.Upload()

    f = None